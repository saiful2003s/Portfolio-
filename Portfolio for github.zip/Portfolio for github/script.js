
// Select all elements with class 'typed-text'
const typedElements = document.querySelectorAll('.typed-text');

typedElements.forEach(el => {
  new Typed(el, {
    strings: ["Web Developer", "UI/UX Designer", "Web Designer"],
    typeSpeed: 80,
    backSpeed: 50,
    loop: true
  });
});


// Socket section

document.addEventListener("DOMContentLoaded", () => {

  function updateSocketDateTime() {
    const now = new Date();

    const date = now.toLocaleDateString("en-BD", {
      day: "numeric",
      month: "long",
      year: "numeric"
    });

    const time = now.toLocaleTimeString("en-BD");

    document.querySelectorAll(".current-date-time").forEach(item => {
      item.innerText = `${date} | ${time}`;
    });
  }

  updateSocketDateTime();
  setInterval(updateSocketDateTime, 1000);


  /* ===== SCROLL TO TOP ===== */
  const scrollBtn = document.querySelector(".scroll-top-btn");

  if (scrollBtn) {

    window.addEventListener("scroll", () => {
      if (window.scrollY > 150) {
        scrollBtn.style.display = "block";
      } else {
        scrollBtn.style.display = "none";
      }
    });

    scrollBtn.addEventListener("click", () => {
      window.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    });

  }

});


// Contact Form 


const form = document.getElementById("contactForm");
const nameInput = document.getElementById("name");
const emailInput = document.getElementById("email");
const messageInput = document.getElementById("message");

form.addEventListener("submit", function (e) {
  e.preventDefault();

  let isValid = true;

  // Name validation
  if (nameInput.value.trim() === "") {
    showError(nameInput, "Name is required");
    isValid = false;
  } else {
    showSuccess(nameInput);
  }

  // Email validation
  if (emailInput.value.trim() === "") {
    showError(emailInput, "Email is required");
    isValid = false;
  } else if (!isValidEmail(emailInput.value)) {
    showError(emailInput, "Invalid email format");
    isValid = false;
  } else {
    showSuccess(emailInput);
  }

  // Message validation
  if (messageInput.value.trim().length < 10) {
    showError(messageInput, "Message must be at least 10 characters");
    isValid = false;
  } else {
    showSuccess(messageInput);
  }

  if (isValid) {
    alert("Form submitted successfully!");
    form.reset();
    clearStyles();
  }
});

function showError(input, message) {
  const errorText = input.nextElementSibling;
  errorText.innerText = message;
  input.classList.add("error");
  input.classList.remove("success");
}

function showSuccess(input) {
  const errorText = input.nextElementSibling;
  errorText.innerText = "";
  input.classList.add("success");
  input.classList.remove("error");
}

function clearStyles() {
  document.querySelectorAll(".form-control").forEach(el => {
    el.classList.remove("success");
  });
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}


function initMap() {
  const location = {
    lat: 23.8103,  // Dhaka latitude
    lng: 90.4125   // Dhaka longitude
  };

  const map = new google.maps.Map(document.getElementById("map"), {
    zoom: 14,
    center: location
  });

  new google.maps.Marker({
    position: location,
    map: map,
    title: "Our Office Location"
  });
}





















